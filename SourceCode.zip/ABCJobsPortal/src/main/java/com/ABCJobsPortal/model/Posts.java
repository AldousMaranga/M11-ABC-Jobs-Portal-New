package com.ABCJobsPortal.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "post")
public class Posts {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "post_id")
	private Long postId;
	
	@Column(name = "user_details_id")
	private Long userDetailsId;
	
	@OneToOne(optional=false) // Use FetchType.LAZY for better performance
    @JoinColumn(name = "user_details_id", referencedColumnName = "user_details_id", insertable=false, updatable=false) // Column name in the post table that references userId
	private UserDetails user;
	
	@Column(name = "post_body")
	private String postBody;
	
	@Column(name = "created_at")
	private String createdAt;
	
	public Posts() {}
	public Posts(Long postId, Long userDetailsId, String postBody, String createdAt, UserDetails user) {
		this.postId = postId;
		this.userDetailsId = userDetailsId;
		this.createdAt = createdAt;
		this.postBody = postBody;
		this.user = user;
	}

	public Long getPostId() {
		return postId;
	}

	public void setPostId(Long postId) {
		this.postId = postId;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public UserDetails getUser() {
		return user;
	}
	public void setUser(UserDetails user) {
		this.user = user;
	}
	public Long getUserDetailsId() {
		return userDetailsId;
	}
	public void setUserDetailsId(Long userDetailsId) {
		this.userDetailsId = userDetailsId;
	}
	public String getPostBody() {
		return postBody;
	}
	public void setPostBody(String postBody) {
		this.postBody = postBody;
	}
}
