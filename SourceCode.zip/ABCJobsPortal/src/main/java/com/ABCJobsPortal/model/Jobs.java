package com.ABCJobsPortal.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "jobs")
public class Jobs {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "job_id")
	private Long jobId;

	@Column(name = "user_details_id")
	private String userDetailsId;

	@Column(name = "user_interested")
	private int userInterested;

	@Column(name = "user_apply")
	private int userApply;

	@Column(name = "company_name")
	private String companyName;

	@Column(name = "position")
	private String position;

	@Column(name = "description")
	private String description;

	@Column(name = "type")
	private String type;

	@Column(name = "qualification")
	private String qualification;

	@Column(name = "industry")
	private String industry;
	
//	@OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
//	private List<JobApply> jobApplies = new ArrayList<>();

	public Jobs() {

	}

	public Jobs(Long jobId, String userDetailsId, int userInterested, int userApply, String companyName,
			String position, String description, String type, String qualification, String industry
//			, List<JobApply> jobApplies
			) {
		this.jobId = jobId;
		this.userDetailsId = userDetailsId;
		this.userInterested = userInterested;
		this.userApply = userApply;
		this.companyName = companyName;
		this.position = position;
		this.description = description;
		this.type = type;
		this.qualification = qualification;
		this.industry = industry;
		//this.jobApplies = jobApplies;
	}

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public String getUserDetailsId() {
		return userDetailsId;
	}

	public void setUserDetailsId(String userDetailsId) {
		this.userDetailsId = userDetailsId;
	}

	public int getUserInterested() {
		return userInterested;
	}

	public void setUserInterested(int userInterested) {
		this.userInterested = userInterested;
	}

	public int getUserApply() {
		return userApply;
	}

	public void setUserApply(int userApply) {
		this.userApply = userApply;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

//	public List<JobApply> getJobApplies() {
//		return jobApplies;
//	}
//
//	public void setJobApplies(List<JobApply> jobApplies) {
//		this.jobApplies = jobApplies;
//	}
}
