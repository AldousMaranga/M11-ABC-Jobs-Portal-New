package com.ABCJobsPortal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "comments")
public class Comment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "comment_id")
	private Long commentId;
	
	@Column(name = "post_id")
	private Long postId;
	
	@Column(name = "user_details_id")
	private Long userDetailsId;
	
	@Column(name = "comment_body")
	private String commentBody;
	
	@Column(name = "comment_date")
	private String commentDate;
	
	@ManyToOne(optional=false) // Use FetchType.LAZY for better performance
    @JoinColumn(name = "post_id", referencedColumnName = "post_id", insertable=false, updatable=false) // Column name in the post table that references userId
	private Posts post;
	
	@OneToOne(optional=false) // Use FetchType.LAZY for better performance
    @JoinColumn(name = "user_details_id", referencedColumnName = "user_details_id", insertable=false, updatable=false) // Column name in the post table that references userId
	private UserDetails user;

	public Comment () {
		
	}
	
	public Comment (Long commentId, Long postId, Long userDetailsId, String commentBody, String commentDate, Posts post, UserDetails user) {
		this.commentId = commentId;
		this.postId = postId;
		this.userDetailsId = userDetailsId;
		this.commentBody = commentBody;
		this.commentDate = commentDate;
		this.post = post;
		this.user = user;
	}
	
	public Long getCommentId() {
		return commentId;
	}

	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}

	public Long getPostId() {
		return postId;
	}

	public void setPostId(Long postId) {
		this.postId = postId;
	}

	public Long getUserDetailsId() {
		return userDetailsId;
	}

	public void setUserDetailsId(Long userDetailsId) {
		this.userDetailsId = userDetailsId;
	}

	public String getCommentBody() {
		return commentBody;
	}

	public void setCommentBody(String commentBody) {
		this.commentBody = commentBody;
	}

	public Posts getPost() {
		return post;
	}

	public void setPost(Posts post) {
		this.post = post;
	}

	public UserDetails getUser() {
		return user;
	}

	public void setUser(UserDetails user) {
		this.user = user;
	}

	public String getCommentDate() {
		return commentDate;
	}

	public void setCommentDate(String commentDate) {
		this.commentDate = commentDate;
	}
}
