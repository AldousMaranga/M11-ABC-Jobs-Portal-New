package com.ABCJobsPortal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "reply")
public class Reply {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "reply_id")
	private Long replyId;
	
	@Column(name = "comment_id")
	private Long commentId;
	
	@Column(name = "user_details_id")
	private Long userDetailsId;
	
	@Column(name = "reply_body")
	private String replyBody;
	
	@Column(name = "reply_date")
	private String replyDate;
	
	@ManyToOne(optional=false) // Use FetchType.LAZY for better performance
    @JoinColumn(name = "comment_id", referencedColumnName = "comment_id", insertable=false, updatable=false) // Column name in the post table that references userId
	private Comment comment;
	
	@OneToOne(optional=false) // Use FetchType.LAZY for better performance
    @JoinColumn(name = "user_details_id", referencedColumnName = "user_details_id", insertable=false, updatable=false) // Column name in the post table that references userId
	private UserDetails user;


	public Reply() {

	}

	public Reply(Long replyId, Long commentId, Long userDetailsId, String replyBody, String replyDate, Comment comment, UserDetails user) {
		super();
		this.replyId = replyId;
		this.commentId = commentId;
		this.userDetailsId = userDetailsId;
		this.replyBody = replyBody;
		this.replyDate = replyDate;
		this.comment = comment;
		this.user = user;
	}
	
	public Long getReplyId() {
		return replyId;
	}

	public void setReplyId(Long replyId) {
		this.replyId = replyId;
	}

	public Long getCommentId() {
		return commentId;
	}

	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}

	public Long getUserDetailsId() {
		return userDetailsId;
	}

	public void setUserDetailsId(Long userDetaisId) {
		this.userDetailsId = userDetaisId;
	}

	public String getReplyBody() {
		return replyBody;
	}

	public void setReplyBody(String replyBody) {
		this.replyBody = replyBody;
	}

	public String getReplyDate() {
		return replyDate;
	}

	public void setReplyDate(String replyDate) {
		this.replyDate = replyDate;
	}

	public Comment getComment() {
		return comment;
	}

	public void setComment(Comment comment) {
		this.comment = comment;
	}

	public UserDetails getUser() {
		return user;
	}

	public void setUser(UserDetails user) {
		this.user = user;
	}
	
}
