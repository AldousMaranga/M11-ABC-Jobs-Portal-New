package com.ABCJobsPortal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ABCJobsPortal.model.Comment;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {
	
	@Query(value = "SELECT * FROM comments ORDER BY comment_id DESC", nativeQuery = true)
	public List<Comment> getAllComments();

	public List<Comment> getCommentsByPostId(Long postId);
	

}
