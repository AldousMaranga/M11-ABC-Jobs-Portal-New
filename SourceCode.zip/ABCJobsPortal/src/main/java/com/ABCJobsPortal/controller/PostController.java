package com.ABCJobsPortal.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ABCJobsPortal.model.Comment;
import com.ABCJobsPortal.model.Posts;
import com.ABCJobsPortal.model.Reply;
import com.ABCJobsPortal.model.UserDetails;
import com.ABCJobsPortal.repository.PostsRepository;
import com.ABCJobsPortal.repository.UserDetailsRepository;
import com.ABCJobsPortal.repository.UsersRepository;
import com.ABCJobsPortal.service.CommentService;
import com.ABCJobsPortal.service.PostService;
import com.ABCJobsPortal.service.ReplyService;
import com.ABCJobsPortal.service.UserDetailsService;
import com.ABCJobsPortal.service.UsersService;

@Controller
public class PostController {
	
	@Autowired
	PostService postService;
	
	@Autowired
	UsersService userService;
	
	@Autowired
	UsersRepository userRepo;
	
	@Autowired
	PostsRepository postRepo;
	
	@Autowired
	UserDetailsService udService;
	
	@Autowired 
	UserDetailsRepository udRepo;
	
	@Autowired
	CommentService commentService;
	
	@Autowired
	ReplyService replyService;
	
	
	
	@RequestMapping(value="/addPost", method = RequestMethod.POST)
    public String post(@ModelAttribute("post") Posts post, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId != null) {
        	UserDetails user = udRepo.findByUserDetailsId(userId);
            if (user != null) {
                // Set the user object associated with the post
                post.setUserDetailsId(userId);

                // Set createdAt and other post properties
                post.setCreatedAt(java.time.LocalDate.now().toString());

                // Save the post to the PostRepository
                postService.addPost(post);
            } else {
            	return "redirect:/dashboard";
            }
        } else {
        	return "redirect:/dashboard";
        }

        return "redirect:/dashboard";
    }
	
	@RequestMapping(value="/addComment", method = RequestMethod.POST)
    public String comment(@ModelAttribute("comment") Comment comment, @RequestParam("postId") Long postId, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");

        if (userId != null) {	
        	UserDetails user = udRepo.findByUserDetailsId(userId);
            if (user != null) {
                // Set the user object associated with the post
                comment.setUserDetailsId(userId);
                comment.setPostId(postId);
                comment.setCommentDate(java.time.LocalDate.now().toString());
                commentService.addComments(comment);
            } else {
            	return "redirect:/dashboard";
            }
        } else {
        	return "redirect:/dashboard";
        }

        return "redirect:/dashboard";
    }
	
	@RequestMapping(value="/addReply", method = RequestMethod.POST)
	public String addReply(@RequestParam("commentId") Long commentId, @RequestParam("replyContent") String replyContent, HttpSession session) {
	    Long userId = (Long) session.getAttribute("userId");

	    if (userId != null) {    
	        UserDetails user = udRepo.findByUserDetailsId(userId);
	        if (user != null) {
	            // Create and set the reply object
	            Reply reply = new Reply();
	            
	            
	            reply.setUserDetailsId(userId);
	            
	            reply.setCommentId(commentId);
	            reply.setReplyBody(replyContent);
	            reply.setReplyDate(java.time.LocalDate.now().toString());
	            
	            replyService.addReply(reply); // Add the reply
	            
	            return "redirect:/dashboard";
	        } else {
	        	return "redirect:/dashboard";
	        }
	    } else {
	    	return "redirect:/dashboard";
	    }
	}
}
